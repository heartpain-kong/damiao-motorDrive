﻿using System;
using System.Drawing;

namespace dmactool
{
    internal class BrushConverter
    {
        internal Brush ConvertFromInvariantString(string v)
        {
            throw new NotImplementedException();
        }
    }
}