﻿namespace System.Windows
{
    internal class Media
    {
        public static object Brushes { get; internal set; }

        internal class Brush
        {
        }
    }
}